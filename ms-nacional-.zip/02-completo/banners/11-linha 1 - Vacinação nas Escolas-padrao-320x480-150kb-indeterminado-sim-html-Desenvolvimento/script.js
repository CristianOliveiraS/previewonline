var animations = [
  {
    action: function() {
        var confettiDrop = [
          [
            {
              id: '#i01',
              duration: 250,
              delayBefore: 0,
              delayAfter: 0,
              animations: {opacity:1,scale:[1.25,1.25],}
            },
            {
              id: '#i01',
              duration: 9050,
              delayBefore: 0,
              delayAfter: 0,
              animations: {scale:[1,1.25]}
            },
          ],
        ];
        var confettiAnim = new WAnimation(confettiDrop, {loop: false, clearAfterEnd: false});
        confettiAnim.startAnimation();
    }
  },
  [
    {
      id: '#i02',
      duration: 650,
      delayBefore: 350,
      delayAfter: 0,
      easing: "easeOutCubic",
      animations: {opacity:1, left:0, top:0}
    },
    {
      id: '#i05',
      duration: 750,
      delayBefore: 450,
      delayAfter: 0,
      easing: "easeOutCubic",
      animations: {opacity:1, left:0, top:0}
    },
    {
      id: '#i04',
      duration: 750,
      delayBefore: 550,
      delayAfter: 0,
      easing: "easeOutCubic",
      animations: {opacity:1, left:0, top:0}
    },
    {
      id: '#i03',
      duration: 750,
      delayBefore: 650,
      delayAfter: 2500,
      easing: "easeOutCubic",
      animations: {opacity:1, left:0, top:0}
    },
  ],
  [
    {
      id: '#i05',
      duration: 250,
      delayBefore: 0,
      delayAfter: 0,
      easing: "easeOutCubic",
      animations: {opacity:0, left:0, top:"5%"}
    },
    {
      id: '#i04',
      duration: 250,
      delayBefore: 100,
      delayAfter: 0,
      easing: "easeOutCubic",
      animations: {opacity:0, left:0, top:"5%"}
    },
    {
      id: '#i03',
      duration: 250,
      delayBefore: 200,
      delayAfter: 0,
      easing: "easeOutCubic",
      animations: {opacity:0, left:0, top:"5%"}
    },
    {
      id: '#i02',
      duration: 250,
      delayBefore: 300,
      delayAfter: 0,
      easing: "easeOutCubic",
      animations: {opacity:0, left:0, top:"5%"}
    },
  ],
  [
    {
      id: '#i06',
      duration: 650,
      delayBefore: 350,
      delayAfter: 0,
      easing: "easeOutCubic",
      animations: {opacity:1, left:0, top:0}
    },
    {
      id: '#i07',
      duration: 750,
      delayBefore: 450,
      delayAfter: 3500,
      easing: "easeOutCubic",
      animations: {opacity:1, left:0, top:0}
    },
  ],
  [
    {
      id: '#i07',
      duration: 250,
      delayBefore: 0,
      delayAfter: 0,
      easing: "easeOutCubic",
      animations: {opacity:0, left:0, top:"-5%"}
    },
    {
      id: '#i06',
      duration: 250,
      delayBefore: 100,
      delayAfter: 0,
      easing: "easeOutCubic",
      animations: {opacity:0, left:0, top:"5%"}
    },
  ],
  [
    {
      id: '#i08',
      duration: 650,
      delayBefore: 350,
      delayAfter: 0,
      easing: "easeOutCubic",
      animations: {opacity:1, left:0, top:0}
    },
    {
      id: '#i09',
      duration: 750,
      delayBefore: 450,
      delayAfter: 0,
      easing: "easeOutCubic",
      animations: {opacity:1, left:0, top:0}
    },
    {
      id: '#i10',
      duration: 750,
      delayBefore: 550,
      delayAfter: 0,
      easing: "easeOutCubic",
      animations: {opacity:1, left:0, top:0}
    },
    {
      id: '#i11',
      duration: 750,
      delayBefore: 650,
      delayAfter: 3500,
      easing: "easeOutCubic",
      animations: {opacity:1, left:0, top:0}
    },
  ],
  [
    {
      id: '#i08',
      duration: 250,
      delayBefore: 0,
      delayAfter: 0,
      easing: "easeOutCubic",
      animations: {opacity:0, left:0, top:"5%"}
    },
    {
      id: '#i11',
      duration: 250,
      delayBefore: 100,
      delayAfter: 0,
      easing: "easeOutCubic",
      animations: {opacity:0, left:0, top:"5%"}
    },
    {
      id: '#i10',
      duration: 250,
      delayBefore: 200,
      delayAfter: 0,
      easing: "easeOutCubic",
      animations: {opacity:0, left:0, top:"5%"}
    },
    {
      id: '#i09',
      duration: 250,
      delayBefore: 300,
      delayAfter: 0,
      easing: "easeOutCubic",
      animations: {opacity:0, left:0, top:"5%"}
    },
  ],
  [
    {
      id: '#i12',
      duration: 650,
      delayBefore: 350,
      delayAfter: 0,
      easing: "easeOutCubic",
      animations: {opacity:1, left:0, top:0}
    },
    {
      id: '#i13',
      duration: 750,
      delayBefore: 450,
      delayAfter: 0,
      easing: "easeOutCubic",
      animations: {opacity:1, left:0, top:0}
    },
    {
      id: '#i14',
      duration: 750,
      delayBefore: 550,
      delayAfter: 2500,
      easing: "easeOutCubic",
      animations: {opacity:1, left:0, top:0}
    },
  ],
 ]
 new WAnimation(animations, {
     loop: false,
     clearAfterEnd: false,
   }).startAnimation();      